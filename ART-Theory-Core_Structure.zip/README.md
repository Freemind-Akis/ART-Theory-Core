# ART: Ajallisen Resonanssin Teoria

This section covers the art: ajallisen resonanssin teoria module of the ART theory.
