# Lensing

This section covers the lensing module of the ART theory.
