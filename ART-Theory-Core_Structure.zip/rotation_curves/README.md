# Rotation curves

This section covers the rotation curves module of the ART theory.
