# Derivation

This section covers the derivation module of the ART theory.
